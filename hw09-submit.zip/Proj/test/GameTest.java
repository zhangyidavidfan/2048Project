import org.junit.Test;
import org.junit.Assert;
/** Put your OWN test cases in this file, for all classes in the assignment. */
public class GameTest {
	
	@Test
    public void checkSetState(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][0] = 2;
        test[0][1] = 2;
        start.setState(test);
        Assert.assertArrayEquals("CHecking set state", test, start.getState());
    }
	
	@Test
    public void MoveDown1WithCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][0] = 2;
        test[0][1] = 2;
        start.setState(test);
        start.moveDown();
        int [][] fin = new int[4][4];
        fin[0][3] = 4;
        Assert.assertArrayEquals("Move down with collision on one tile", fin, start.getState());
    }
	
	@Test
    public void MoveDown1WithoutCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][0] = 2;
        test[1][1] = 2;
        start.setState(test);
        start.moveDown();
        int [][] fin = new int[4][4];
        fin[0][3] = 2;
        fin[1][3] = 2;
        Assert.assertArrayEquals("Move down without collision on one tile", fin, start.getState());
    }
	
	@Test
    public void MoveDownMultipleWithCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][0] = 2;
        test[0][1] = 2;
        test[1][1] = 4;
        test[1][2] = 4;
        test[3][0] = 2;
        test[3][3] = 2;
        start.setState(test);
        start.moveDown();
        int [][] fin = new int[4][4];
        fin[0][3] = 4;
        fin[1][3] = 8;
        fin[3][3] = 4;
        Assert.assertArrayEquals("Move down with collision on multiple tile", fin, start.getState());
    }
	
	@Test
    public void MoveDownMultipleWithoutCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][0] = 2;
        test[1][0] = 2;
        test[1][1] = 4;
        test[1][2] = 16;
        test[2][3] = 2;
        start.setState(test);
        start.moveDown();
        int [][] fin = new int[4][4];
        fin[0][3] = 2;
        fin[1][1] = 2;
        fin[1][2] = 4;
        fin[1][3] = 16;
        fin[2][3] = 2;
        Assert.assertArrayEquals("Move down without collision on multiple tile", fin, start.getState());
    }
	
	@Test
    public void MoveDownWithNoMoves(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][3] = 2;
        test[1][3] = 2;
        test[2][3] = 2;
        start.setState(test);
        start.moveDown();
        int [][] fin = new int[4][4];
        fin[0][3] = 2;
        fin[1][3] = 2;
        fin[2][3] = 2;
        Assert.assertArrayEquals("Move down with no moves", fin, start.getState());
    }
	
	@Test
    public void MoveDownAvoidDoubleCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][1] = 2;
        test[0][2] = 2;
        test[0][3] = 4;
        start.setState(test);
        start.moveDown();
        int [][] fin = new int[4][4];
        fin[0][2] = 4;
        fin[0][3] = 4;
        Assert.assertArrayEquals("Move down avoid double collision", fin, start.getState());
    }
	
	@Test
    public void MoveLeft1WithCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[3][0] = 2;
        test[1][0] = 2;
        start.setState(test);
        start.moveLeft();
        int [][] fin = new int[4][4];
        fin[0][0] = 4;
        Assert.assertArrayEquals("Move left with collision on one tile", fin, start.getState());
    }
	
	@Test
    public void MoveLef1WithoutCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][0] = 2;
        test[1][1] = 2;
        start.setState(test);
        start.moveLeft();
        int [][] fin = new int[4][4];
        fin[0][0] = 2;
        fin[0][1] = 2;
        Assert.assertArrayEquals("Move left without collision on one tile", fin, start.getState());
    }
	
	@Test
    public void MoveLeftMultipleWithCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[3][0] = 2;
        test[1][0] = 2;
        test[1][1] = 4;
        test[2][1] = 4;
        test[2][3] = 2;
        test[3][3] = 2;
        start.setState(test);
        start.moveLeft();
        int [][] fin = new int[4][4];
        fin[0][0] = 4;
        fin[0][1] = 8;
        fin[0][3] = 4;
        Assert.assertArrayEquals("Move left with collision on multiple tile", fin, start.getState());
    }
	
	@Test
    public void MoveLeftMultipleWithoutCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[3][0] = 2;
        test[3][1] = 2;
        test[1][1] = 4;
        test[2][3] = 16;
        test[3][3] = 2;
        start.setState(test);
        start.moveLeft();
        int [][] fin = new int[4][4];
        fin[0][0] = 2;
        fin[0][1] = 4;
        fin[1][1] = 2;
        fin[0][3] = 16;
        fin[1][3] = 2;
        Assert.assertArrayEquals("Move left without collision on multiple tile", fin, start.getState());
    }
	
	@Test
    public void MoveLeftWithNoMoves(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][3] = 2;
        test[0][2] = 2;
        test[0][1] = 2;
        start.setState(test);
        start.moveLeft();
        int [][] fin = new int[4][4];
        fin[0][3] = 2;
        fin[0][2] = 2;
        fin[0][1] = 2;
        Assert.assertArrayEquals("Move left with no moves", fin, start.getState());
    }
	
	@Test
    public void MoveLeftAvoidDoubleCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[1][0] = 2;
        test[2][0] = 2;
        test[3][0] = 4;
        start.setState(test);
        start.moveLeft();
        int [][] fin = new int[4][4];
        fin[0][0] = 4;
        fin[1][0] = 4;
        Assert.assertArrayEquals("Move left avoid double collision", fin, start.getState());
    }
	
	@Test
    public void MoveRight1WithCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[2][0] = 2;
        test[0][0] = 2;
        start.setState(test);
        start.moveRight();
        int [][] fin = new int[4][4];
        fin[3][0] = 4;
        Assert.assertArrayEquals("Move right with collision on one tile", fin, start.getState());
    }
	
	@Test
    public void MoveRight1WithoutCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][0] = 2;
        test[1][1] = 2;
        start.setState(test);
        start.moveRight();
        int [][] fin = new int[4][4];
        fin[3][0] = 2;
        fin[3][1] = 2;
        Assert.assertArrayEquals("Move right without collision on one tile", fin, start.getState());
    }
	
	@Test
    public void MoveRightMultipleWithCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[3][0] = 2;
        test[1][0] = 2;
        test[1][1] = 4;
        test[2][1] = 4;
        test[2][3] = 2;
        test[3][3] = 2;
        start.setState(test);
        start.moveRight();
        int [][] fin = new int[4][4];
        fin[3][0] = 4;
        fin[3][1] = 8;
        fin[3][3] = 4;
        Assert.assertArrayEquals("Move right with collision on multiple tile", fin, start.getState());
    }
	
	@Test
    public void MoveRightMultipleWithoutCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[3][0] = 2;
        test[3][1] = 2;
        test[1][1] = 4;
        test[2][3] = 16;
        test[3][3] = 2;
        start.setState(test);
        start.moveRight();
        int [][] fin = new int[4][4];
        fin[3][0] = 2;
        fin[2][1] = 4;
        fin[3][1] = 2;
        fin[2][3] = 16;
        fin[3][3] = 2;
        Assert.assertArrayEquals("Move right without collision on multiple tile", fin, start.getState());
    }
	
	@Test
    public void MoveRightWithNoMoves(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[3][3] = 2;
        test[3][2] = 2;
        test[3][1] = 2;
        start.setState(test);
        start.moveRight();
        int [][] fin = new int[4][4];
        fin[3][3] = 2;
        fin[3][2] = 2;
        fin[3][1] = 2;
        Assert.assertArrayEquals("Move right with no moves", fin, start.getState());
    }
	
	@Test
    public void MoveRightAvoidDoubleCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[1][0] = 2;
        test[2][0] = 2;
        test[3][0] = 4;
        start.setState(test);
        start.moveRight();
        int [][] fin = new int[4][4];
        fin[3][0] = 4;
        fin[2][0] = 4;
        Assert.assertArrayEquals("Move right avoid double collision", fin, start.getState());
    }
	
	@Test
    public void MoveUp1WithCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][0] = 2;
        test[0][1] = 2;
        start.setState(test);
        start.moveUp();
        int [][] fin = new int[4][4];
        fin[0][0] = 4;
        Assert.assertArrayEquals("Move up with collision on one tile", fin, start.getState());
    }
	
	@Test
    public void MoveUp1WithoutCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][3] = 2;
        test[1][3] = 2;
        start.setState(test);
        start.moveUp();
        int [][] fin = new int[4][4];
        fin[0][0] = 2;
        fin[1][0] = 2;
        Assert.assertArrayEquals("Move up without collision on one tile", fin, start.getState());
    }
	
	@Test
    public void MoveUpMultipleWithCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][0] = 2;
        test[0][1] = 2;
        test[1][1] = 4;
        test[1][2] = 4;
        test[3][0] = 2;
        test[3][3] = 2;
        start.setState(test);
        start.moveUp();
        int [][] fin = new int[4][4];
        fin[0][0] = 4;
        fin[1][0] = 8;
        fin[3][0] = 4;
        Assert.assertArrayEquals("Move up with collision on multiple tile", fin, start.getState());
    }
	
	@Test
    public void MoveUpMultipleWithoutCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][3] = 2;
        test[1][1] = 2;
        test[1][2] = 4;
        test[1][3] = 16;
        test[2][3] = 2;
        start.setState(test);
        start.moveUp();
        int [][] fin = new int[4][4];
        fin[0][0] = 2;
        fin[1][0] = 2;
        fin[1][1] = 4;
        fin[1][2] = 16;
        fin[2][0] = 2;
        Assert.assertArrayEquals("Move up without collision on multiple tile", fin, start.getState());
    }
	
	@Test
    public void MoveUpWithNoMoves(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][0] = 2;
        test[1][0] = 2;
        test[2][0] = 2;
        start.setState(test);
        start.moveUp();
        int [][] fin = new int[4][4];
        fin[0][0] = 2;
        fin[1][0] = 2;
        fin[2][0] = 2;
        Assert.assertArrayEquals("Move up with no moves", fin, start.getState());
    }
	
	@Test
    public void MoveUpAvoidDoubleCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][1] = 2;
        test[0][2] = 2;
        test[0][3] = 4;
        start.setState(test);
        start.moveUp();
        int [][] fin = new int[4][4];
        fin[0][0] = 4;
        fin[0][1] = 4;
        Assert.assertArrayEquals("Move up avoid double collision", fin, start.getState());
    }
	@Test
    public void isDead(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][0] = 2;
        test[0][1] = 4;
        test[0][2] = 8;
        test[0][3] = 16;
        test[1][0] = 16;
        test[1][1] = 8;
        test[1][2] = 4;
        test[1][3] = 2;
        test[2][0] = 2;
        test[2][1] = 4;
        test[2][2] = 8;
        test[2][3] = 16;
        test[3][0] = 16;
        test[3][1] = 8;
        test[3][2] = 4;
        test[3][3] = 2;
        start.setState(test);
        Assert.assertTrue("No more moves",start.isDead());
    }
	
	@Test
    public void isNotDeadPossibleCollision(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][0] = 2;
        test[0][1] = 4;
        test[0][2] = 8;
        test[0][3] = 16;
        test[1][0] = 16;
        test[1][1] = 4;
        test[1][2] = 4;
        test[1][3] = 2;
        test[2][0] = 2;
        test[2][1] = 4;
        test[2][2] = 8;
        test[2][3] = 16;
        test[3][0] = 16;
        test[3][1] = 8;
        test[3][2] = 4;
        test[3][3] = 2;
        start.setState(test);
        Assert.assertFalse("Could Collide",start.isDead());
    }
	
	@Test
    public void isNotDeadBlankSpace(){
        Board start = new Board();
        int [][] test = new int[4][4];
        test[0][0] = 2;
        test[0][1] = 4;
        test[0][2] = 8;
        test[0][3] = 16;
        test[1][0] = 16;
        test[1][3] = 2;
        test[2][0] = 2;
        test[2][1] = 4;
        test[2][2] = 8;
        test[2][3] = 16;
        test[3][0] = 16;
        test[3][1] = 8;
        test[3][2] = 4;
        test[3][3] = 2;
        start.setState(test);
        Assert.assertFalse("Could Collide",start.isDead());
    }
	
	@Test
	 public void Won(){
	        Board start = new Board();
	        int [][] test = new int[4][4];
	        test[0][0] = 2048;
	        test[0][1] = 4;
	        test[0][2] = 8;
	        test[0][3] = 16;
	        test[1][0] = 16;
	        test[1][1] = 4;
	        test[1][2] = 4;
	        test[1][3] = 2;
	        test[2][0] = 2;
	        test[2][1] = 4;
	        test[2][2] = 8;
	        test[2][3] = 16;
	        test[3][0] = 16;
	        test[3][1] = 8;
	        test[3][2] = 4;
	        test[3][3] = 2;
	        start.setState(test);
	        Assert.assertTrue("game won",start.isWinner());
	    }
}