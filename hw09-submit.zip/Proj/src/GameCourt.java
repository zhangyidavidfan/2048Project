/**
 * CIS 120 Game HW
 * (c) University of Pennsylvania
 * @version 2.1, Apr 2017
 */

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;

import javax.swing.*;

/**
 * GameCourt
 * 
 * This class holds the primary game logic for how different objects interact with one another. Take
 * time to understand how the timer interacts with the different methods and how it repaints the GUI
 * on every tick().
 */
@SuppressWarnings("serial")
public class GameCourt extends JPanel {

    // the state of the game logic
    private Board board; //create game board
    private int score = 0; //

    public boolean playing = false; // whether the game is running 
    private JLabel status; // Current status text, i.e. "Running..."
    private JLabel scoreBoard; //Current Score
    private JFrame frame;
    private int[][] savedState;
    private boolean read;
    private String inputName;
    private Map<String,Integer> topScores = new TreeMap<String, Integer>();

    // Game constants
    public static final int COURT_WIDTH = 300;
    public static final int COURT_HEIGHT = 300;
    public static final int SQUARE_VELOCITY = 4;

    // Update interval for timer, in milliseconds
    public static final int INTERVAL = 35;

    public GameCourt(JLabel status, JLabel scoreBoard, String inputName, boolean read, 
    		int[][] savedState, Map<String,Integer> leaderBoard, JFrame frame, int savedScore) {
    	//checking for saved state, if user prompts yes then read in saved state
    	if(read) {
    		this.read = read;
    		this.savedState = savedState;
    		this.score = savedScore;
    	}
    	this.frame = frame;
    	//read in the leaderboard
    	topScores = leaderBoard;
        // creates border around the court area, JComponent method
        setBorder(BorderFactory.createLineBorder(Color.BLACK));

        // The timer is an object which triggers an action periodically with the given INTERVAL. We
        // register an ActionListener with this timer, whose actionPerformed() method is called each
        // time the timer triggers. We define a helper method called tick() that actually does
        // everything that should be done in a single timestep.
        Timer timer = new Timer(INTERVAL, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tick();
            }
        });
        timer.start(); // MAKE SURE TO START THE TIMER!

        // Enable keyboard focus on the court area.
        // When this component has the keyboard focus, key events are handled by its key listener.
        setFocusable(true);

        // This key listener allows board to update its movement when corresponding keys are pressed
        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
            	int pts = 0;
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    pts = board.moveLeft();
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                	 pts = board.moveRight();
                } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                	pts = board.moveDown();
                } else if (e.getKeyCode() == KeyEvent.VK_UP) {
                	pts = board.moveUp();
                }
                if(pts > 0) {
                    board.update();
                    repaint();
                	}
                    if(pts != 1) {
                    	score += pts;
                    	scoreBoard.setText("score: " + Integer.toString(score));
                    }
                    boolean z = board.isDead();
                    if(z == true) {
                    	status.setText("You Lost");
                    	playing = false;
                        JOptionPane.showMessageDialog(frame, "You lost", "SORRY!", JOptionPane.PLAIN_MESSAGE);
                    }
                    boolean g = board.isWinner();
                    if(g == true) {
                    	status.setText("You Won");
                    	playing = false;
                        JOptionPane.showMessageDialog(frame, "You won", "Congrats!", JOptionPane.PLAIN_MESSAGE);
                    }
            }

            public void keyReleased(KeyEvent e) {
            }
        });

        this.status = status;
        this.scoreBoard = scoreBoard;
        this.inputName = inputName;
    }

    /**
     * start the game
     */
    public void start() {
        board = new Board();
        if(read) {
    		board.setState(savedState);
    	}

        playing = true;
        status.setText("Running...");
        scoreBoard.setText("score:" + score);

        // Make sure that this component has the keyboard focus
        requestFocusInWindow();
    }
    
    // resume the game
    public void resume() {
        playing = true;

        // Make sure that this component has the keyboard focus
        requestFocusInWindow();
    }
    
    //reset the game to its initial state
    public void reset() {
        board = new Board();
        score = 0;

        playing = true;
        status.setText("Running...");
        scoreBoard.setText("score: " + score);

        // Make sure that this component has the keyboard focus
        requestFocusInWindow();
    }
    
    //save the progress
    public int[][] saveProgress() {
    	return board.getState();
    }
    
    public int saveProgressScore() {
    	return score;
    }
    
    //save the score
    public void saveScore() {
    	if(!(topScores.containsKey(inputName)) || score > topScores.get(inputName)) {
    		topScores.put(inputName, score);
    	}
    }
    
    //save the current leader board (top 3 scores)
    public String getLeaderBoard() {
    	String [] lead = new String [3];
    	int [] scores = new int[3];
    	String fin = "";
    	Object[] scores_obj = topScores.values().toArray();
    	int[] scores_int = new int[scores_obj.length];
    	for (int i = 0; i < scores_obj.length; i++)
			scores_int[i] = (Integer)scores_obj[i];
    	Arrays.sort(scores_int);
    	int val = 0;
    	if(scores_int.length >= 3) {
    		val = (int) scores_int[scores_int.length - 3];
    	}
    	lead[0] = "";
    	lead[1] = "";
    	lead[2] = "";
    	int j = 0;
    	for(String i : topScores.keySet()) {
    		if(topScores.get(i) >= val) {
    		lead[j] =  i +" " +
    				(Integer.toString(topScores.get(i))) + "\n";
    		scores[j] = topScores.get(i);
    		j=j+1;
    		}
    		if(j == 3) {
    			break;
    		}
    	}
    	if(scores[0] >= scores[1]) {
    		if(scores[1] >= scores[2]) {
    			fin = lead[0] + lead[1] + lead[2];
    		}
    		else if(scores[2] >= scores[0]) {
    			fin = lead[2] + lead[0] + lead[1];
    		}
    		else {
    			fin = lead[0] + lead[2] + lead[1];
    		}
    	}
    	else {
    		if(scores[0] >= scores[2]) {
    			fin = lead[1] + lead[0] + lead[2];
    		}
    		else if(scores[2] >= scores[1]) {
    			fin = lead[2] + lead[1] + lead[0];
    		}
    		else {
    			fin = lead[1] + lead[2] + lead[0];
    		}
    	}
    	return fin;
    }

    /**
     * This method is called every time the timer defined in the constructor triggers.
     */
    void tick() {
        if (playing) {
            // update the display
            repaint();
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        board.draw(g);
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(COURT_WIDTH, COURT_HEIGHT);
    }
}