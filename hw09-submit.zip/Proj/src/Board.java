import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Board {
	//initializing the board and create variables
	 public static final int X = 4;
	 public static final int Y = 4;
	 public static final int BoardX = 300;
	 public static final int BoardY = 300;
	 public int[][] board= new int [X][Y];
	 
	 //constructor for the board and initializing the first two tiles at random
	 public Board() {
		 int x1 = 0;
	     int y1 = 0;
         int x2 = 0;
         int y2 = 0;
		 while(x1 == x2 && y1 == y2) {
	        x1 = (int)(Math.random() * 4);
	        y1 = (int)(Math.random() * 4);
	        x2 = (int)(Math.random() * 4);
	        y2 = (int)(Math.random() * 4);
		 }
	     int val1 = 2;
	     int val2 = 2;
         if (Math.random() >= 0.8) {
           val1 = 4;
         }
	     if (Math.random() >= 0.8) {
	       val2 = 4;
   	     }
	     board[x1][y1] = val1;
         board[x2][y2] = val2;
	 }
	 
	 //method to draw the board
	 //input: Graphics 
	 //output: no objects but a drawing on the console
	 public void draw(Graphics g) {
	     g.setColor(Color.BLACK);
	     g.drawRect(0, 0, BoardX, BoardY);
	     BufferedImage img_2 = null;
	     BufferedImage img_4 = null;
	     BufferedImage img_8 = null;
	     BufferedImage img_16 = null;
	     BufferedImage img_32 = null;
	     BufferedImage img_64 = null;
	     BufferedImage img_128 = null;
	     BufferedImage img_256 = null;
	     BufferedImage img_512 = null;
	     BufferedImage img_1024 = null;
	     BufferedImage img_2048 = null;
	     BufferedImage img_grid = null;
	     try {
	    	 img_2 = ImageIO.read(new File("files/2_tiles.jpg")); 
	    	 img_4 = ImageIO.read(new File("files/4_tiles.jpg")); 
	    	 img_8 = ImageIO.read(new File("files/8_tiles.jpg")); 
	    	 img_16 = ImageIO.read(new File("files/16_tiles.jpg")); 
	    	 img_32 = ImageIO.read(new File("files/32_tiles.jpg")); 
	    	 img_64 = ImageIO.read(new File("files/64_tiles.jpg")); 
	    	 img_128 = ImageIO.read(new File("files/128_tiles.jpg")); 
	    	 img_256 = ImageIO.read(new File("files/256_tiles.jpg"));
	    	 img_512 = ImageIO.read(new File("files/512_tiles.jpg")); 
	    	 img_1024 = ImageIO.read(new File("files/1024_tiles.jpg")); 
	    	 img_2048 = ImageIO.read(new File("files/2048_tiles.jpg")); 
	    	 img_grid = ImageIO.read(new File("files/2048-grid.png"));
	     }
	     catch(IOException e) {
	     }
	     g.drawImage(img_grid,0, 0,BoardX, BoardY, null);
	     for(int i = 0; i < 4; i++) {
	    	 for(int j = 0; j < 4; j++) {
		    	 if(board[i][j] > 0) {
		    		 if(board[i][j] == 2) {
		    			 g.drawImage(img_2,i*BoardX/4, j*BoardY/4,BoardX/4, BoardY/4, null);
		    		 }
		    		 else if(board[i][j] == 4) {
		    			 g.drawImage(img_4,i*BoardX/4, j*BoardY/4,BoardX/4, BoardY/4, null);
		    		 }
		    		 else if(board[i][j] == 8) {
		    			 g.drawImage(img_8,i*BoardX/4, j*BoardY/4,BoardX/4, BoardY/4, null);
		    		 }
		    		 else if(board[i][j] == 16) {
		    			 g.drawImage(img_16,i*BoardX/4, j*BoardY/4,BoardX/4, BoardY/4, null);
		    		 }
		    		 else if(board[i][j] == 32) {
		    			 g.drawImage(img_32,i*BoardX/4, j*BoardY/4,BoardX/4, BoardY/4, null);
		    		 }
		    		 else if(board[i][j] == 64) {
		    			 g.drawImage(img_64,i*BoardX/4, j*BoardY/4,BoardX/4, BoardY/4, null);
		    		 }
		    		 else if(board[i][j] == 128) {
		    			 g.drawImage(img_128,i*BoardX/4, j*BoardY/4,BoardX/4, BoardY/4, null);
		    		 }
		    		 else if(board[i][j] == 256) {
		    			 g.drawImage(img_256,i*BoardX/4, j*BoardY/4,BoardX/4, BoardY/4, null);
		    		 }
		    		 else if(board[i][j] == 512) {
		    			 g.drawImage(img_512,i*BoardX/4, j*BoardY/4,BoardX/4, BoardY/4, null);
		    		 }
		    		 else if(board[i][j] == 1024) {
		    			 g.drawImage(img_1024,i*BoardX/4, j*BoardY/4,BoardX/4, BoardY/4, null);
		    		 }
		    		 else if(board[i][j] == 2048) {
		    			 g.drawImage(img_2048,i*BoardX/4, j*BoardY/4,BoardX/4, BoardY/4, null);
		    		 }
		    	 }
		    	 else{
	    		 }
		     } 
	     }
	 }
	 
	 //method to update a new tile
	 //input: None
	 //output: no objects but an updated array
	 public void update() {
		 int x1 = -1;
	     int y1 = -1;
		 while(x1 < 0 || y1 < 0 || board[x1][y1] > 0) {
	        x1 = (int)(Math.random() * 4);
	        y1 = (int)(Math.random() * 4);
		 }
		 int val1 = 2;
         if (Math.random() >= 0.8) {
           val1 = 4;
         }
         board[x1][y1] = val1;
	 }
	
	//find the adjacent of the tile
	//input: coordinate of a tile
    //output: a list of adjacent tiles(left, right, up, down); if not present the value will be -1	 
	public int [] adjacent(int x, int y){
		int [] nums = new int [4];
		if(x - 1 >= 0) {
			nums[0] = board[x-1][y];
		}
		else {
			nums[0] = -1;
		}
		if(x + 1 < X) {
			nums[1] = board[x+1][y];
		}
		else {
			nums[1] = -1;
		}
		if(y - 1 >= 0) {
			nums[2] = board[x][y-1];
		}
		else {
			nums[2] = -1;
		}
		if(y + 1 < Y) {
			nums[3] = board[x][y+1];
		}
		else {
			nums[3] = -1;
		}
		return nums;
	}
	
	public boolean isWinner() { 
		 boolean isWinner = false;
	     for(int i = 0; i < X; i++) {
	    	 for(int j = 0; j < Y; j++) {
	    		 if(board[i][j] == 2048) {
	    			 isWinner = true;
	    		 }
	    	 }
	     }
	     return isWinner;
	}
	
	//method checking if anymore move is left
	//input: None
	//output: Boolean indicating whether or not there are no moves left	
	public boolean isDead() { 
	 boolean isDead = true;
     for(int i = 0; i < X; i++) {
    	 for(int j = 0; j < Y; j++) {
    		 if(board[i][j] == 0) {
    			 isDead = false;
    		 }
    		 else if(board[i][j] > 0) {
    			 int [] num_list = adjacent(i,j);
    			 for(int p = 0; p < num_list.length; p++) {
    				 if(num_list[p] == board[i][j]) {
    					 isDead = false;
    				 }
    			 }	 
    		 }
    	 }
     }
     return isDead;
	}
     
	//method to move all tile to the left and check for collision
	//input: None
	//output: 1 if there are no collision but a move is made
	//		  0 if there are no moves made
	//		  sum of all tiles after collision if collision is present
	//		  tiles will also be updated to corresponding position
	 public int moveLeft() {
		 boolean [] row = new boolean [4];
		 int num = 0;
		 int score = 0;
		 for(int i = 1; i < X; i++) {
	    	 for(int j = 0; j < Y; j++) {
	    		 if(board[i][j] > 0) {
	    				 int z = i;
	    				 while(board[z-1][j] == 0) {
	    					 num = 1;
	    					 board[z-1][j] = board[z][j];
	    					 board[z][j] = 0;
	    					 if (z - 1 > 0) {
	    						 z = z-1;
	    					 }
	    					 else {
	    						 break;
	    					 }
	    				 }
	    				 if(board[z][j] > 0 && z >0 && !row[j] && board[z][j] == board[z-1][j]) {
	    					 board[z-1][j] = 2 * board[z-1][j]; 
	    					 board[z][j] = 0;
	    					 num += board[z-1][j];
	    					 score += board[z-1][j];
	    					 row[j] = true;
	    				 }
	    		 }
	    	 }
	     }
		 if(num == 1 && score == 0) {
			 return num;
		 }
		 else {
			 return score;
		 }
	 }

	 //method to move all tile to the right and check for collision
	 //input: None
	 //output: 1 if there are no collision but a move is made
	 //		  0 if there are no moves made
	 //		  sum of all tiles after collision if collision is present
	 //		  tiles will also be updated to corresponding position
	 public int moveRight() {
		 boolean [] row = new boolean [4];
		 int num = 0;
		 int score = 0;
		 for(int i = X-2; i >= 0; i--) {
	    	 for(int j = 0; j < Y; j++) {
	    		 if(board[i][j] > 0) {
	    			 int z = i;
	    			 while(board[z + 1][j] == 0) {
	    				 num = 1;
	    				 board[z+1][j] = board[z][j];
	    				 board[z][j] = 0;
	    				 if(z + 1 < X - 1) {
	    					 z = z + 1;
	    				 }
	    				 else {
    						 break;
    					 }
	    			 }
	    			 if(board[z][j] > 0 && z < 3 && !row[j] && board[z][j] == board[z+1][j]) {
    					 board[z+1][j] = 2 * board[z+1][j]; 
    					 board[z][j] = 0;
    					 num += board[z+1][j];
    					 score += board[z+1][j];
    					 row[j] = true;
    				 }
	    		 }
	    	 }
	     }
		 if(num == 1 && score == 0) {
			 return num;
		 }
		 else {
			 return score;
		 }
	 }

	 //method to move all tile up and check for collision	 
	 //input: None
	 //output: 1 if there are no collision but a move is made
	 //		  0 if there are no moves made
	 //		  sum of all tiles after collision if collision is present
	 //		  tiles will also be updated to corresponding position
	 public int moveUp() {
		 boolean [] col = new boolean [4];
		 int num = 0;
		 int score = 0;
		 for(int j = 1; j <Y ; j++) {
	    	 for(int i = 0; i < X; i++) {
	    		 if(board[i][j] > 0) {
	    			 int z = j;
	    			 while(board[i][z-1] == 0) {
	    				 num = 1;
	    				 board[i][z-1] = board[i][z];
	    				 board[i][z] = 0;
	    				 if(z - 1 > 0) {
	    					 z = z - 1;
	    				 }
	    				 else {
    						 break;
    					 }
	    			 }
	    			 if(board[i][z] > 0 && z > 0 && !col[i] && board[i][z] == board[i][z - 1]) {
    					 board[i][z-1] = 2 * board[i][z - 1]; 
    					 board[i][z] = 0;
    					 num += board[i][z-1];
    					 score += board[i][z-1];
    					 col[i] = true;
    				 }
	    		 }
	    	 }
	     }
		 if(num == 1 && score == 0) {
			 return num;
		 }
		 else {
			 return score;
		 }
	 }

	 //method to move all tile down and check for collision
	 //input: None
	 //output: 1 if there are no collision but a move is made
	 //		  0 if there are no moves made
	 //		  sum of all tiles after collision if collision is present
	 //		  tiles will also be updated to corresponding position
	 public int moveDown() {
		 int num = 0;
		 int score = 0;
		 boolean [] col = new boolean [4];
		 for(int j = Y - 2; j >= 0 ; j--) {
	    	 for(int i = 0; i < X; i++) {
	    		 if(board[i][j] > 0) {
	    			 int z = j;
	    			 while(board[i][z+1] == 0) {
	    				 num = 1;
	    				 board[i][z+1] = board[i][z];
	    				 board[i][z] = 0;
	    				 if(z + 1 < Y - 1) {
	    					 z = z + 1;
	    				 }
	    				 else {
    						 break;
    					 }
	    			 }
	    			 if(board[i][z] > 0 && z < 3 && !col[i] && board[i][z] == board[i][z + 1]) {
    					 board[i][z+1] = 2 * board[i][z + 1]; 
    					 board[i][z] = 0;
    					 num += board[i][z+1];
    					 score += board[i][z+1];
    					 col[i] = true;
    				 }
	    		 }
	    	 }
	     }
		 if(num == 1 && score == 0) {
			 return num;
		 }
		 else {
			 return score;
		 }
	 }
	 
	 //method to get all the tile location of the board
	 //input: None
	 //output: 2d array representation of the board
	 public int[][] getState() {
		 return board;
	 }
	 
	 //method to read in the saved state of the board
	 //input: 2d array
	 //output: no object but an updated version of the board
	 public void setState(int[][] savedState) {
		 this.board = savedState;
	 }
}
