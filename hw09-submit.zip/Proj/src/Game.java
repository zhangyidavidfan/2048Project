/**
 * CIS 120 Game HW
 * (c) University of Pennsylvania
 * @version 2.1, Apr 2017
 */

// imports necessary libraries for Java swing
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Map;
import java.util.TreeMap;

import javax.swing.*;

/**
 * Game Main class that specifies the frame and widgets of the GUI
 */
public class Game implements Runnable {
    public void run() {
        // NOTE : recall that the 'final' keyword notes immutability even for local variables.

        // Top-level frame in which game components live
        // Be sure to change "TOP LEVEL FRAME" to the name of your game
        final JFrame frame = new JFrame("TOP LEVEL FRAME");
        frame.setLocation(300, 300);

        // Status panel
        final JPanel status_panel = new JPanel();
        frame.add(status_panel, BorderLayout.SOUTH);
        final JLabel status = new JLabel("Running...");
        status_panel.add(status);
        
        //score board
        final JLabel scoreBoard = new JLabel("0");
        
        //instructions
        final String INSTRUCTIONS = ( "WELCOME TO 2048!\n"
        		+ "2048 is a single-player sliding block puzzle game \n"
        		+ "designed by Italian web developer Gabriele Cirulli. \n"
        		+ "The game's objective is to slide numbered tiles on a grid \n"
        		+ "to combine them to create a tile with the number 2048.\n" 
        		+ "upon starting you could choose whether or not you would \n"
        		+ "want to read in the saved progress from the last game \n" 
        		+"\nCONTROLS: \n"
        		+"Use the arrow keys to move the tile \n"
        		+"Use the save score button to save your score \n"
        		+"Use the save progress button to save the game progress \n"
        		+"Use the leader board button to check the leader board \n"
        		+ "Use the reset button to reset the board"
        		+ "\nNOTE \n"
        		+ "Reading in saved Progress will not read in the scores");
        JOptionPane.showMessageDialog(frame, INSTRUCTIONS, "INSTRUCTIONS:", JOptionPane.PLAIN_MESSAGE);
        
        //asking for user name
        String inputName = "";
        while (inputName == null || inputName.equals("")) {
        	inputName = JOptionPane.showInputDialog(frame, "Please enter a username.", "USER INPUT", 
        			JOptionPane.PLAIN_MESSAGE);
        }
        
        //asking if user wants to load progress from last time
        int choice = JOptionPane.showConfirmDialog(frame, "Do you want to load the progress");
        int[][] savedState = new int[4][4];
        int savedScore = 0;
        
        //create leader board
        Map<String, Integer> leaderBoard = new TreeMap<String, Integer>();
        
        //saved user choice on whether or not to save and read in the saved progress from stored file
        boolean read = false;
        if(choice == JOptionPane.YES_OPTION) {
        	try {
    			BufferedReader k = new BufferedReader(new FileReader("files/savedProg.txt"));
    			String l = k.readLine();
    			int p = 0;
    			int tempi = 0;
    			int tempj = 0;
				read = true;
				savedScore = Integer.parseInt(l);
				l = k.readLine();	
				while(l != null) {
					tempi = p/4;
    				tempj = p%4;
    				savedState[tempi][tempj] = Integer.parseInt(l);
    				l = k.readLine();
    				p = p + 1;
    			}
    		} catch (IOException e2) {
    			// TODO Auto-generated catch block
    			e2.printStackTrace();
    		}
        }
        //read in leader board
        try {
			BufferedReader l = new BufferedReader(new FileReader("files/LeaderBoard.txt"));
			String q = l.readLine();
			String user = "";
			int score = 0;
			while(q != null) {
				user = q.substring(0, q.indexOf(" "));
				score = Integer.valueOf(q.substring(q.indexOf(" ")+1, q.length()));
				leaderBoard.put(user, score);
				q = l.readLine();
			}
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

        // Main playing area
        final GameCourt court = new GameCourt(status, scoreBoard, inputName, read, savedState, 
        		leaderBoard, frame, savedScore);
        frame.add(court, BorderLayout.CENTER);

        // Reset button
        final JPanel control_panel = new JPanel();
        frame.add(control_panel, BorderLayout.NORTH);
        control_panel.add(scoreBoard);

        // Note here that when we add an action listener to the reset button, we define it as an
        // anonymous inner class that is an instance of ActionListener with its actionPerformed()
        // method overridden. When the button is pressed, actionPerformed() will be called.
        final JButton reset = new JButton("Reset");
        reset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                court.reset();
            }
        });
        control_panel.add(reset);
        
        //create button to show leader board
        final JButton leaderBoardButton = new JButton("leaderBoard");
        leaderBoardButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	JOptionPane.showMessageDialog(frame, court.getLeaderBoard(), "Leader Board:", JOptionPane.PLAIN_MESSAGE);
            	court.resume();
            }
        });
        control_panel.add(leaderBoardButton);
        
        //create button to save progress
        final JButton SaveProgress = new JButton("SaveProgress");
        SaveProgress.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	int[][] state = court.saveProgress();
            	try {
					Writer out = new BufferedWriter(new FileWriter("files/savedProg.txt"));
					out.write(Integer.toString(court.saveProgressScore()) + "\n");
					for(int i = 0; i < state.length; i++) {
						for(int j = 0; j < state[0].length; j++) {
							out.write(Integer.toString(state[i][j]) + "\n");
							out.flush();
						}
					}
			        out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
            	court.resume();
            }
        });
        status_panel.add(SaveProgress);
        
        //create button to save score
        final JButton SaveScore = new JButton("SaveScore");
        SaveScore.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
            	court.saveScore();
            	try {
					Writer out = new BufferedWriter(new FileWriter("files/LeaderBoard.txt"));
					out.write(court.getLeaderBoard());
			        out.flush();
			        out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
            	court.resume();
            }
        });
        status_panel.add(SaveScore);

        // Put the frame on the screen
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        // Start game
        court.start();
    }

    /**
     * Main method run to start and run the game. Initializes the GUI elements specified in Game and
     * runs it. IMPORTANT: Do NOT delete! You MUST include this in your final submission.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Game());
    }
}